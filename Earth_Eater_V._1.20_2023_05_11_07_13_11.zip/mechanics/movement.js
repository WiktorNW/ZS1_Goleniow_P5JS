function keyPressed(){
  if (game==1){
    if(keyCode===UP_ARROW || keyCode===87){
      sun.goUp();
    }
  }
  
}